package com.aurora.music.ui

import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import com.aurora.music.data.Song

@Composable
fun PlayerScreen(vm: MusicViewModel, song: Song, accent: Color, onClose: () -> Unit, onAdd: (Song) -> Unit) {
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val pos by vm.position.collectAsStateWithLifecycle()
    val dur by vm.duration.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val repeat by vm.repeat.collectAsStateWithLifecycle()
    val art by rememberArt(song)
    val img = art.image
    var dragY by remember { mutableFloatStateOf(0f) }
    var seeking by remember { mutableStateOf<Float?>(null) }
    val scale by animateFloatAsState(if (playing) 1f else 0.88f, spring(dampingRatio = 0.6f), label = "artScale")
    val total = if (dur > 0) dur else song.durationMs

    Box(
        Modifier.fillMaxSize().background(Bg).pointerInput(Unit) {
            detectVerticalDragGestures(
                onDragEnd = { dragY = 0f },
                onVerticalDrag = { _, d -> dragY += d; if (dragY > 220f) { dragY = 0f; onClose() } }
            )
        }
    ) {
        if (img != null) Image(img, null, Modifier.fillMaxSize().blur(70.dp).alpha(0.6f), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(0.25f), Bg.copy(0.85f), Bg))))

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                Text("NOW PLAYING", color = Color.White.copy(0.7f), fontSize = 12.sp, letterSpacing = 2.sp)
                IconButton(onClick = { onAdd(song) }) { Icon(Icons.Rounded.LibraryAdd, null, tint = Color.White) }
            }
            Spacer(Modifier.weight(1f))
            ArtImage(
                song,
                Modifier.fillMaxWidth().aspectRatio(1f)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .shadow(28.dp, RoundedCornerShape(32.dp), spotColor = accent),
                32.dp
            )
            Spacer(Modifier.weight(1f))

            Column(Modifier.fillMaxWidth()) {
                Text(song.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Color.White.copy(0.7f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Slider(
                value = seeking ?: pos.toFloat().coerceAtMost(total.toFloat()),
                onValueChange = { seeking = it },
                onValueChangeFinished = { seeking?.let { vm.seekTo(it.toLong()) }; seeking = null },
                valueRange = 0f..total.coerceAtLeast(1).toFloat(),
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(0.25f))
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt((seeking ?: pos.toFloat()).toLong()), color = Color.White.copy(0.6f), fontSize = 12.sp)
                Text(fmt(total), color = Color.White.copy(0.6f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(Icons.Rounded.Shuffle, null, tint = if (shuffle) accent else Color.White.copy(0.7f))
                }
                IconButton(onClick = vm::previous, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(38.dp))
                }
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(Color.White).clickable { vm.toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = vm::next, modifier = Modifier.size(56.dp)) {
                    Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(38.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, null,
                        tint = if (repeat != Player.REPEAT_MODE_OFF) accent else Color.White.copy(0.7f)
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

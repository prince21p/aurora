package com.aurora.music.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import com.aurora.music.data.Song
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AuroraApp(vm: MusicViewModel) {
    val ctx = LocalContext.current

    // ---- permissions ----
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    fun hasAudio() = ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasAudio()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudio()
        if (granted) vm.loadSongs()
    }
    LaunchedEffect(Unit) { if (granted) vm.loadSongs() else launcher.launch(perms) }

    if (!granted) {
        Box(Modifier.fillMaxSize().background(Bg).padding(32.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Aurora needs access to your music files", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { launcher.launch(perms) }) { Text("Allow access") }
            }
        }
        return
    }

    // ---- state ----
    val songs by vm.songs.collectAsStateWithLifecycle()
    val feed by vm.feed.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val content by vm.playlistContent.collectAsStateWithLifecycle()
    val current by vm.current.collectAsStateWithLifecycle()
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val pos by vm.position.collectAsStateWithLifecycle()
    val dur by vm.duration.collectAsStateWithLifecycle()

    val art by rememberArt(current)
    val accent by animateColorAsState(lerp(art.color, Color.White, 0.3f), tween(800), label = "accent")
    val bgTint by animateColorAsState(art.color, tween(800), label = "bgTint")

    var tab by remember { mutableIntStateOf(0) }
    var playerOpen by remember { mutableStateOf(false) }
    var openPlaylist by remember { mutableStateOf<Long?>(null) }
    var pickerSong by remember { mutableStateOf<Song?>(null) }
    var newPlaylistFor by remember { mutableStateOf<Song?>(null) }
    var creating by remember { mutableStateOf(false) }

    BackHandler(enabled = playerOpen || openPlaylist != null) {
        if (playerOpen) playerOpen = false else openPlaylist = null
    }

    val ui = remember(vm) {
        UiActions(
            play = { q, i -> vm.playQueue(q, i) },
            addToPlaylist = { pickerSong = it },
            playNext = { vm.playNext(it); Toast.makeText(ctx, "Playing next", Toast.LENGTH_SHORT).show() },
            enqueue = { vm.enqueue(it); Toast.makeText(ctx, "Added to queue", Toast.LENGTH_SHORT).show() }
        )
    }

    CompositionLocalProvider(LocalAccent provides accent, LocalCurrentId provides current?.id) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to bgTint.copy(0.5f), 0.55f to Bg, 1f to Bg)
            )
        ) {
            Crossfade(targetState = if (openPlaylist != null) 3 else tab, label = "screen") { t ->
                when (t) {
                    0 -> HomeScreen(songs, feed, ui)
                    1 -> LibraryScreen(songs, ui)
                    2 -> PlaylistsScreen(playlists, content, { openPlaylist = it }, { creating = true })
                    else -> {
                        val p = playlists.firstOrNull { it.id == openPlaylist }
                        if (p != null) PlaylistDetail(
                            p, content[p.id].orEmpty(), ui,
                            onBack = { openPlaylist = null },
                            onDelete = { vm.deletePlaylist(p.id); openPlaylist = null },
                            onRemove = { vm.removeFromPlaylist(p.id, it.id) }
                        )
                    }
                }
            }

            // Dynamic-island style pill
            val cur = current
            if (cur != null && !playerOpen) {
                Box(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
                    IslandPill(cur, playing, accent, vm::toggle)
                }
            }

            // Mini player + floating nav
            Column(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (cur != null && !playerOpen) {
                    MiniPlayer(
                        cur, bgTint, playing, if (dur > 0) pos.toFloat() / dur else 0f,
                        onToggle = vm::toggle, onNext = vm::next, onOpen = { playerOpen = true }
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Row(
                    Modifier.glass(CircleShape, 0.10f).background(Color(0xCC14111F)).padding(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    NavItem(Icons.Rounded.Home, "Home", tab == 0 && openPlaylist == null, accent) { tab = 0; openPlaylist = null }
                    NavItem(Icons.Rounded.MusicNote, "Library", tab == 1 && openPlaylist == null, accent) { tab = 1; openPlaylist = null }
                    NavItem(Icons.Rounded.LibraryMusic, "Playlists", tab == 2 || openPlaylist != null, accent) { tab = 2; openPlaylist = null }
                }
            }

            // Full-screen player
            AnimatedVisibility(
                visible = playerOpen && current != null,
                enter = slideInVertically { it }, exit = slideOutVertically { it }
            ) {
                current?.let { PlayerScreen(vm, it, accent, { playerOpen = false }, { s -> pickerSong = s }) }
            }
        }

        // ---- dialogs ----
        pickerSong?.let { s ->
            PlaylistPicker(
                playlists,
                onPick = { id -> vm.addToPlaylist(id, s.id); pickerSong = null; Toast.makeText(ctx, "Added to playlist", Toast.LENGTH_SHORT).show() },
                onNew = { newPlaylistFor = s; pickerSong = null },
                onDismiss = { pickerSong = null }
            )
        }
        newPlaylistFor?.let { s ->
            NameDialog("New playlist", "Create", { name -> vm.createPlaylist(name, s.id); newPlaylistFor = null }, { newPlaylistFor = null })
        }
        if (creating) {
            NameDialog("New playlist", "Create", { name -> vm.createPlaylist(name); creating = false }, { creating = false })
        }
    }
}

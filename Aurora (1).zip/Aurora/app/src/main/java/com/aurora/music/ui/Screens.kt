package com.aurora.music.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.music.data.PlaylistEntity
import com.aurora.music.data.Song
import com.aurora.music.recommend.Feed
import java.util.Calendar

@Composable
private fun topInset() = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 60.dp

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Late night vibes"
}

@Composable
fun EmptyCard(text: String) {
    Box(Modifier.padding(20.dp).fillMaxWidth().glass().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White.copy(0.8f), textAlign = TextAlign.Center)
    }
}

@Composable
fun HomeScreen(songs: List<Song>, feed: Feed, ui: UiActions) {
    LazyColumn(contentPadding = PaddingValues(top = topInset(), bottom = 230.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(greeting(), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("${songs.size} songs on your phone", color = Color.White.copy(0.6f))
            }
        }
        if (songs.isEmpty()) {
            item { EmptyCard("No songs found yet.\nDownload some MP3s to your phone and reopen the app.") }
            return@LazyColumn
        }
        item {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton("Shuffle all", Icons.Rounded.Shuffle, true) { ui.play(songs.shuffled(), 0) }
                PillButton("Play all", Icons.Rounded.PlayArrow, false) { ui.play(songs, 0) }
            }
        }
        if (feed.forYou.isNotEmpty()) {
            item { SectionTitle(if (feed.personalized) "Made for you" else "Fresh picks") }
            item { CardRow(feed.forYou, ui) }
        }
        if (feed.mostPlayed.isNotEmpty()) {
            item { SectionTitle("On repeat") }
            itemsIndexed(feed.mostPlayed, key = { _, s -> "mp${s.id}" }) { i, s ->
                Box(Modifier.padding(horizontal = 12.dp)) { SongRow(s, ui, feed.mostPlayed, i) }
            }
        }
        if (feed.recent.isNotEmpty()) {
            item { SectionTitle("Recently played") }
            item { CardRow(feed.recent, ui) }
        }
        if (feed.topArtist != null && feed.moreFromArtist.size > 1) {
            item { SectionTitle("More from ${feed.topArtist}") }
            item { CardRow(feed.moreFromArtist, ui) }
        }
        if (!feed.personalized) {
            item { EmptyCard("Play a few songs or build a playlist and Aurora will learn your taste.") }
        }
    }
}

@Composable
fun LibraryScreen(songs: List<Song>, ui: UiActions) {
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) }
    val sorted = remember(songs) { songs.sortedBy { it.title.lowercase() } }
    val filtered = remember(sorted, query) {
        if (query.isBlank()) sorted else sorted.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }
    val artists = remember(filtered) { filtered.groupBy { it.artist }.toList().sortedBy { it.first.lowercase() } }
    val albums = remember(filtered) { filtered.groupBy { it.album }.toList().sortedBy { it.first.lowercase() } }

    LazyColumn(contentPadding = PaddingValues(top = topInset(), bottom = 230.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Library", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(14.dp))
                TextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Search songs, artists, albums") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    modifier = Modifier.fillMaxWidth().glass(CircleShape),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
                    )
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Songs", "Artists", "Albums").forEachIndexed { i, label ->
                        FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
        when (mode) {
            0 -> itemsIndexed(filtered, key = { _, s -> s.id }) { i, s ->
                Box(Modifier.padding(horizontal = 12.dp)) { SongRow(s, ui, filtered, i) }
            }
            1 -> items(artists, key = { it.first }) { (name, list) -> GroupRow(name, list, ui) }
            else -> items(albums, key = { it.first }) { (name, list) -> GroupRow(name, list, ui) }
        }
    }
}

@Composable
private fun GroupRow(name: String, list: List<Song>, ui: UiActions) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(16.dp))
            .clickable { ui.play(list, 0) }.padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtImage(list.first(), Modifier.size(56.dp), 28.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${list.size} songs", color = Color.White.copy(0.6f), fontSize = 13.sp)
        }
        Icon(Icons.Rounded.PlayArrow, null, tint = Color.White.copy(0.7f))
    }
}

@Composable
fun PlaylistsScreen(playlists: List<PlaylistEntity>, content: Map<Long, List<Song>>, onOpen: (Long) -> Unit, onNew: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(top = topInset(), bottom = 230.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Playlists", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(14.dp))
                PillButton("New playlist", Icons.Rounded.Add, true, onNew)
                Spacer(Modifier.height(14.dp))
            }
        }
        if (playlists.isEmpty()) item { EmptyCard("No playlists yet.\nCreate one, then add songs from the ⋮ menu on any song.") }
        items(playlists, key = { it.id }) { p ->
            val list = content[p.id].orEmpty()
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp).fillMaxWidth().glass()
                    .clickable { onOpen(p.id) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArtImage(list.firstOrNull(), Modifier.size(64.dp), 16.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${list.size} songs", color = Color.White.copy(0.6f), fontSize = 13.sp)
                }
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White.copy(0.7f))
            }
        }
    }
}

@Composable
fun PlaylistDetail(
    playlist: PlaylistEntity, songs: List<Song>, ui: UiActions,
    onBack: () -> Unit, onDelete: () -> Unit, onRemove: (Song) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(top = topInset(), bottom = 230.dp)) {
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, null, tint = Color.White.copy(0.8f)) }
                }
                Text(playlist.name, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("${songs.size} songs", color = Color.White.copy(0.6f))
                Spacer(Modifier.height(16.dp))
                if (songs.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PillButton("Play", Icons.Rounded.PlayArrow, true) { ui.play(songs, 0) }
                    PillButton("Shuffle", Icons.Rounded.Shuffle, false) { ui.play(songs.shuffled(), 0) }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        if (songs.isEmpty()) item { EmptyCard("Empty playlist.\nOpen the ⋮ menu on any song and choose “Add to playlist”.") }
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            Box(Modifier.padding(horizontal = 12.dp)) { SongRow(s, ui, songs, i, onRemove = { onRemove(s) }) }
        }
    }
}

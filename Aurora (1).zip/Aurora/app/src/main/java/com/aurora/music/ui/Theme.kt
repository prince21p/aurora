package com.aurora.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.aurora.music.data.DefaultAccent

val Bg = Color(0xFF0B0A12)
val LocalAccent = compositionLocalOf { DefaultAccent }
val LocalCurrentId = compositionLocalOf<Long?> { null }

@Composable
fun AuroraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFD0BCFF), background = Bg, surface = Bg,
            onSurface = Color.White, onBackground = Color.White
        ),
        content = content
    )
}

/** Frosted-glass look: translucent white fill + hairline border. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), alpha: Float = 0.08f): Modifier =
    this.clip(shape).background(Color.White.copy(alpha)).border(1.dp, Color.White.copy(0.12f), shape)

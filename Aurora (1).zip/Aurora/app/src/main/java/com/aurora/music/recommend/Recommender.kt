package com.aurora.music.recommend

import com.aurora.music.data.Song
import com.aurora.music.data.SongStat
import com.aurora.music.data.UNKNOWN_ARTIST
import kotlin.random.Random

data class Feed(
    val personalized: Boolean = false,
    val forYou: List<Song> = emptyList(),
    val mostPlayed: List<Song> = emptyList(),
    val recent: List<Song> = emptyList(),
    val topArtist: String? = null,
    val moreFromArtist: List<Song> = emptyList()
)

/**
 * Offline taste model. Every play adds weight to that song's artist and genre,
 * skips subtract, and songs sitting in your playlists count extra. Candidates are
 * then scored by artist/genre affinity, with a bonus for songs you haven't heard
 * yet and a penalty for recent repeats and skipped songs.
 */
object Recommender {
    fun feed(songs: List<Song>, stats: Map<Long, SongStat>, playlistIds: Set<Long>): Feed {
        if (songs.isEmpty()) return Feed()

        val mostPlayed = songs.filter { (stats[it.id]?.plays ?: 0) > 0 }
            .sortedByDescending { stats[it.id]!!.plays }.take(6)
        val recent = songs.filter { (stats[it.id]?.lastPlayed ?: 0L) > 0 }
            .sortedByDescending { stats[it.id]!!.lastPlayed }.take(15)

        val artistW = HashMap<String, Double>()
        val genreW = HashMap<String, Double>()
        for (s in songs) {
            val st = stats[s.id]
            var w = 0.0
            if (st != null) w += st.plays - 0.7 * st.skips
            if (s.id in playlistIds) w += 3.0
            if (w > 0) {
                if (s.artist != UNKNOWN_ARTIST) artistW[s.artist] = (artistW[s.artist] ?: 0.0) + w
                if (s.genre.isNotBlank()) genreW[s.genre] = (genreW[s.genre] ?: 0.0) + w
            }
        }
        if (artistW.isEmpty() && genreW.isEmpty()) {
            return Feed(false, songs.shuffled().take(20), mostPlayed, recent)
        }

        val maxA = (artistW.values.maxOrNull() ?: 1.0).coerceAtLeast(1e-6)
        val maxG = (genreW.values.maxOrNull() ?: 1.0).coerceAtLeast(1e-6)
        val now = System.currentTimeMillis()

        val forYou = songs.map { s ->
            val st = stats[s.id]
            var score = 3.0 * (artistW[s.artist] ?: 0.0) / maxA + 2.0 * (genreW[s.genre] ?: 0.0) / maxG
            if (st == null || st.plays == 0) score += 0.8
            if (s.id in playlistIds) score += 0.3
            if (st != null) {
                score -= 0.6 * st.skips
                if (now - st.lastPlayed < 6 * 3_600_000L) score -= 1.5
            }
            score += Random.nextDouble() * 0.4
            s to score
        }.sortedByDescending { it.second }.take(20).map { it.first }

        val top = artistW.maxByOrNull { it.value }?.key
        val more = top?.let { a -> songs.filter { it.artist == a }.shuffled() }.orEmpty()
        return Feed(true, forYou, mostPlayed, recent, top, more)
    }
}

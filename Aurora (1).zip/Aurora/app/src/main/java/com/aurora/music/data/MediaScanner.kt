package com.aurora.music.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

object MediaScanner {
    /** Finds every audio file (MP3 etc.) on the phone, including your Downloads. */
    fun scan(ctx: Context): List<Song> {
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val projection = mutableListOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION
        )
        val hasGenre = Build.VERSION.SDK_INT >= 30
        if (hasGenre) projection += MediaStore.Audio.Media.GENRE

        val selection = "(${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.MIME_TYPE} = 'audio/mpeg') " +
            "AND ${MediaStore.Audio.Media.DURATION} >= 30000"

        val out = ArrayList<Song>()
        ctx.contentResolver.query(
            collection, projection.toTypedArray(), selection, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iGenre = if (hasGenre) c.getColumnIndex(MediaStore.Audio.Media.GENRE) else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: UNKNOWN_ARTIST
                out += Song(
                    id = id,
                    title = c.getString(iTitle) ?: "Unknown",
                    artist = artist,
                    album = c.getString(iAlbum) ?: "Unknown album",
                    albumId = c.getLong(iAlbumId),
                    genre = if (iGenre >= 0) c.getString(iGenre).orEmpty() else "",
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(collection, id)
                )
            }
        }
        return out
    }
}

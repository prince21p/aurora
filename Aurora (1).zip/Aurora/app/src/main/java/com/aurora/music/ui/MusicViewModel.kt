package com.aurora.music.ui

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.aurora.music.data.*
import com.aurora.music.playback.PlaybackService
import com.aurora.music.recommend.Feed
import com.aurora.music.recommend.Recommender
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MusicViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    // ---- library ----
    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs = _songs.asStateFlow()
    private val _loaded = MutableStateFlow(false)
    val loaded = _loaded.asStateFlow()
    private var byId: Map<Long, Song> = emptyMap()

    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    private val playlistSongs = dao.allPlaylistSongs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val stats = dao.stats().map { l -> l.associateBy { it.songId } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val playlistContent: StateFlow<Map<Long, List<Song>>> = combine(songs, playlistSongs) { s, ps ->
        val map = s.associateBy { it.id }
        ps.groupBy { it.playlistId }.mapValues { (_, l) -> l.mapNotNull { map[it.songId] } }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val feed: StateFlow<Feed> = combine(songs, stats, playlistSongs) { s, st, ps ->
        Recommender.feed(s, st, ps.map { it.songId }.toSet())
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, Feed())

    fun loadSongs() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(app) }
            byId = list.associateBy { it.id }
            _songs.value = list
            _loaded.value = true
            syncCurrent()
        }
    }

    // ---- player state ----
    private val _current = MutableStateFlow<Song?>(null)
    val current = _current.asStateFlow()
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()
    private val _position = MutableStateFlow(0L)
    val position = _position.asStateFlow()
    private val _duration = MutableStateFlow(0L)
    val duration = _duration.asStateFlow()
    private val _shuffle = MutableStateFlow(false)
    val shuffle = _shuffle.asStateFlow()
    private val _repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeat = _repeat.asStateFlow()

    private var future: ListenableFuture<MediaController>
    private var controller: MediaController? = null
    private var lastPos = 0L
    private var countedId: Long? = null

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) { _isPlaying.value = isPlaying }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val prev = _current.value
            // Skipped within the first 10s by the user = a "skip" signal
            if (prev != null && reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK &&
                lastPos < 10_000 && countedId != prev.id
            ) viewModelScope.launch { dao.ensureStat(prev.id); dao.bumpSkip(prev.id) }
            countedId = null
            lastPos = 0
            syncCurrent()
        }

        override fun onEvents(player: Player, events: Player.Events) {
            _shuffle.value = player.shuffleModeEnabled
            _repeat.value = player.repeatMode
            _duration.value = player.duration.coerceAtLeast(0L).takeIf { it > 0 } ?: _current.value?.durationMs ?: 0L
            syncCurrent()
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                _isPlaying.value = c.isPlaying
                _shuffle.value = c.shuffleModeEnabled
                _repeat.value = c.repeatMode
                syncCurrent()
            } catch (e: Exception) {}
        }, ContextCompat.getMainExecutor(app))

        // Progress ticker + "counts as a play after 30s (or half the song)" logic
        viewModelScope.launch {
            while (true) {
                controller?.let { c ->
                    val pos = c.currentPosition
                    _position.value = pos
                    lastPos = pos
                    val cur = _current.value
                    if (c.isPlaying && cur != null && countedId != cur.id &&
                        pos >= minOf(30_000L, cur.durationMs / 2)
                    ) {
                        countedId = cur.id
                        launch { dao.ensureStat(cur.id); dao.bumpPlay(cur.id, System.currentTimeMillis()) }
                    }
                }
                delay(500)
            }
        }
    }

    private fun syncCurrent() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull()
        _current.value = if (id == null) null else byId[id]
    }

    override fun onCleared() {
        MediaController.releaseFuture(future)
        super.onCleared()
    }

    // ---- controls ----
    fun playQueue(queue: List<Song>, index: Int) {
        val c = controller ?: return
        if (queue.isEmpty()) return
        c.setMediaItems(queue.map { it.toMediaItem() }, index.coerceIn(0, queue.lastIndex), 0L)
        c.prepare()
        c.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun previous() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun playNext(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playQueue(listOf(song), 0)
        else c.addMediaItem(c.currentMediaItemIndex + 1, song.toMediaItem())
    }

    fun enqueue(song: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) playQueue(listOf(song), 0) else c.addMediaItem(song.toMediaItem())
    }

    // ---- playlists ----
    fun createPlaylist(name: String, firstSong: Long? = null) = viewModelScope.launch {
        val id = dao.insertPlaylist(PlaylistEntity(name = name.trim()))
        if (firstSong != null) dao.addSong(PlaylistSong(id, firstSong))
    }
    fun addToPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch { dao.addSong(PlaylistSong(playlistId, songId)) }
    fun removeFromPlaylist(playlistId: Long, songId: Long) = viewModelScope.launch { dao.removeSong(playlistId, songId) }
    fun deletePlaylist(id: Long) = viewModelScope.launch { dao.clearPlaylist(id); dao.deletePlaylist(id) }
}

package com.aurora.music.ui

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.music.data.Art
import com.aurora.music.data.ArtInfo
import com.aurora.music.data.DefaultAccent
import com.aurora.music.data.PlaylistEntity
import com.aurora.music.data.Song
import kotlinx.coroutines.delay

class UiActions(
    val play: (List<Song>, Int) -> Unit,
    val addToPlaylist: (Song) -> Unit,
    val playNext: (Song) -> Unit,
    val enqueue: (Song) -> Unit
)

fun fmt(ms: Long): String = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

@Composable
fun rememberArt(song: Song?): State<ArtInfo> {
    val ctx: Context = LocalContext.current
    return produceState(ArtInfo(null, DefaultAccent), song?.id) {
        value = if (song == null) ArtInfo(null, DefaultAccent) else Art.load(ctx, song)
    }
}

@Composable
fun ArtImage(song: Song?, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val art by rememberArt(song)
    val img = art.image
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(art.color.copy(0.9f), Color(0xFF1B1530)))),
        contentAlignment = Alignment.Center
    ) {
        if (img != null) Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(0.7f), modifier = Modifier.fillMaxSize(0.4f))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 22.dp, bottom = 10.dp)
    )
}

@Composable
fun AlbumCard(song: Song, onClick: () -> Unit) {
    Column(Modifier.width(150.dp).clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)) {
        ArtImage(song, Modifier.size(150.dp), 20.dp)
        Spacer(Modifier.height(8.dp))
        Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(song.artist, color = Color.White.copy(0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun CardRow(list: List<Song>, ui: UiActions) {
    LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(list, key = { _, s -> s.id }) { i, s -> AlbumCard(s) { ui.play(list, i) } }
    }
}

@Composable
fun SongRow(song: Song, ui: UiActions, queue: List<Song>, index: Int, onRemove: (() -> Unit)? = null) {
    var menu by remember { mutableStateOf(false) }
    val isCurrent = LocalCurrentId.current == song.id
    val accent = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { ui.play(queue, index) }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtImage(song, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, color = if (isCurrent) accent else Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist}  •  ${fmt(song.durationMs)}", color = Color.White.copy(0.6f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null, tint = Color.White.copy(0.7f)) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { menu = false; ui.playNext(song) })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menu = false; ui.enqueue(song) })
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; ui.addToPlaylist(song) })
                if (onRemove != null) DropdownMenuItem(text = { Text("Remove from this playlist") }, onClick = { menu = false; onRemove() })
            }
        }
    }
}

@Composable
fun PillButton(text: String, icon: ImageVector, filled: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val fg = if (filled) Color.Black else Color.White
    Row(
        Modifier.clip(CircleShape).background(if (filled) accent else Color.White.copy(0.1f))
            .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = fg, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun EqBars(playing: Boolean, color: Color) {
    val t = rememberInfiniteTransition(label = "eq")
    Row(Modifier.height(16.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(420, 540, 360).forEachIndexed { i, d ->
            val h by t.animateFloat(
                0.25f, 1f, infiniteRepeatable(tween(d, easing = LinearEasing), RepeatMode.Reverse), label = "bar$i"
            )
            Box(Modifier.width(3.dp).fillMaxHeight(if (playing) h else 0.3f).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}

/** Dynamic-Island style pill: expands with the song title on every track change, tap to toggle. */
@Composable
fun IslandPill(song: Song, playing: Boolean, accent: Color, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(song.id) { expanded = true; delay(3500); expanded = false }
    Row(
        modifier
            .animateContentSize(spring(dampingRatio = 0.7f))
            .clip(CircleShape).background(Color.Black)
            .border(1.dp, accent.copy(0.35f), CircleShape)
            .clickable { expanded = !expanded }
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        EqBars(playing, accent)
        if (expanded) {
            Spacer(Modifier.width(10.dp))
            Text(song.title, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
            Spacer(Modifier.width(8.dp))
            Icon(
                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White,
                modifier = Modifier.size(22.dp).clickable(onClick = onToggle)
            )
        }
    }
}

@Composable
fun MiniPlayer(song: Song, accent: Color, playing: Boolean, progress: Float, onToggle: () -> Unit, onNext: () -> Unit, onOpen: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(accent.copy(0.55f), Color(0xE61A1626))))
            .border(1.dp, Color.White.copy(0.14f), CircleShape)
            .clickable(onClick = onOpen)
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtImage(song, Modifier.size(46.dp), 23.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, color = Color.White.copy(0.7f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onToggle) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Rounded.SkipNext, null, tint = Color.White) }
        }
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 30.dp).fillMaxWidth().height(2.dp),
            color = Color.White, trackColor = Color.Transparent
        )
    }
}

@Composable
fun NavItem(icon: ImageVector, label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) accent.copy(0.35f) else Color.Transparent, label = "navbg")
    Row(
        Modifier.animateContentSize().clip(CircleShape).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = Color.White)
        if (selected) {
            Spacer(Modifier.width(6.dp))
            Text(label, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun NameDialog(title: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true, placeholder = { Text("Playlist name") }) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onConfirm(text) }) { Text(confirm) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistPicker(playlists: List<PlaylistEntity>, onPick: (Long) -> Unit, onNew: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                TextButton(onClick = onNew, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("New playlist", Modifier.weight(1f))
                }
                playlists.forEach { p ->
                    TextButton(onClick = { onPick(p.id) }, modifier = Modifier.fillMaxWidth()) {
                        Text(p.name, Modifier.fillMaxWidth(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

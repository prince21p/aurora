package com.aurora.music.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val DefaultAccent = Color(0xFF7C4DFF)

data class ArtInfo(val image: ImageBitmap?, val color: Color)

object Art {
    private val cache = LruCache<Long, ArtInfo>(80)

    suspend fun load(ctx: Context, song: Song): ArtInfo = withContext(Dispatchers.IO) {
        cache.get(song.id) ?: run {
            val bmp = thumbnail(ctx, song) ?: embedded(ctx, song)
            val info = if (bmp == null) ArtInfo(null, DefaultAccent) else ArtInfo(bmp.asImageBitmap(), accentOf(bmp))
            cache.put(song.id, info)
            info
        }
    }

    private fun thumbnail(ctx: Context, s: Song): Bitmap? =
        if (Build.VERSION.SDK_INT >= 29) {
            try { ctx.contentResolver.loadThumbnail(s.uri, Size(512, 512), null) } catch (e: Exception) { null }
        } else null

    private fun embedded(ctx: Context, s: Song): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, s.uri)
            r.embeddedPicture?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } catch (e: Exception) { null } finally { try { r.release() } catch (e: Exception) {} }
    }

    private fun accentOf(b: Bitmap): Color {
        val p = Palette.from(b).maximumColorCount(16).generate()
        return Color(p.getVibrantColor(p.getMutedColor(p.getDominantColor(DefaultAccent.toArgb()))))
    }
}

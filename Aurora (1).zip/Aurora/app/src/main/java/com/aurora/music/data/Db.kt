package com.aurora.music.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"])
data class PlaylistSong(
    val playlistId: Long,
    val songId: Long,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "stats")
data class SongStat(
    @PrimaryKey val songId: Long,
    val plays: Int = 0,
    val skips: Int = 0,
    val lastPlayed: Long = 0
)

@Dao
interface MusicDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC") fun playlists(): Flow<List<PlaylistEntity>>
    @Query("SELECT * FROM playlist_songs ORDER BY addedAt") fun allPlaylistSongs(): Flow<List<PlaylistSong>>
    @Query("SELECT * FROM stats") fun stats(): Flow<List<SongStat>>

    @Insert suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_songs WHERE playlistId = :id") suspend fun clearPlaylist(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addSong(ps: PlaylistSong)
    @Query("DELETE FROM playlist_songs WHERE playlistId = :pid AND songId = :sid") suspend fun removeSong(pid: Long, sid: Long)

    @Query("INSERT OR IGNORE INTO stats(songId, plays, skips, lastPlayed) VALUES(:id, 0, 0, 0)") suspend fun ensureStat(id: Long)
    @Query("UPDATE stats SET plays = plays + 1, lastPlayed = :t WHERE songId = :id") suspend fun bumpPlay(id: Long, t: Long)
    @Query("UPDATE stats SET skips = skips + 1 WHERE songId = :id") suspend fun bumpSkip(id: Long)
}

@Database(entities = [PlaylistEntity::class, PlaylistSong::class, SongStat::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MusicDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "aurora.db").build().also { instance = it }
        }
    }
}

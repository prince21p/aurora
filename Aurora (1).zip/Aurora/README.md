# Aurora – a music player for your downloaded MP3s

Kotlin · Jetpack Compose · Media3 (ExoPlayer) · Room

## Run it
1. Install Android Studio (latest stable) and choose **Open** on this folder.
2. Let Gradle sync (it downloads everything; Android Studio creates the Gradle wrapper jar for you).
3. Plug in your phone (USB debugging on) or use an emulator, then press Run.
4. Allow "music and audio" + notifications when asked.

## What's inside
- `playback/PlaybackService` – foreground media service: plays with screen off, lock-screen + notification + Bluetooth controls.
- `data/MediaScanner` – finds every MP3/audio file on the phone (incl. Downloads) through MediaStore.
- `data/Db` – Room: playlists, playlist songs, per-song play/skip stats.
- `recommend/Recommender` – offline suggestions from plays, skips, playlists, artists, genres.
- `ui/` – Compose UI: glass theme, album-art color theming, island pill, mini player, full-screen player.

## Tuning
- Recommendation weights: `Recommender.kt`
- A play counts after 30s (or half the song): `MusicViewModel.kt`
- Accent colors / glass look: `Theme.kt`
